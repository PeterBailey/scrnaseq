# alevinQC 0.99.0

* Preparation for Bioconductor submission

# alevinQC 0.1.0

* Initial version

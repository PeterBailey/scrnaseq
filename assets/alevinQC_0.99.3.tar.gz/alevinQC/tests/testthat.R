library(testthat)
library(alevinQC)

test_check("alevinQC")
